import {
  StateDB,
  stateDiagram_default,
  stateRenderer_v3_unified_default,
  styles_default
} from "./chunk-HIVYH44L.js";
import "./chunk-IFOGPCJD.js";
import "./chunk-QKWZG724.js";
import "./chunk-7GUCAR25.js";
import "./chunk-LY6QTNXD.js";
import "./chunk-OLUBLFQS.js";
import "./chunk-S6W54RO2.js";
import "./chunk-LTYJNPJH.js";
import "./chunk-OAH2Y6RN.js";
import "./chunk-IBGCH5PM.js";
import "./chunk-WGPVAJBU.js";
import "./chunk-BDNRUUWP.js";
import "./chunk-66LTHK5N.js";
import "./chunk-BFAIJW6T.js";
import "./chunk-KEATWLHG.js";
import "./chunk-4ZOZIYPD.js";
import "./chunk-A5434355.js";
import {
  __name
} from "./chunk-DTCXZATX.js";
import "./chunk-X5QR3KD3.js";
import "./chunk-EQCVQC35.js";

// node_modules/mermaid/dist/chunks/mermaid.core/stateDiagram-v2-MP3YSRHH.mjs
var diagram = {
  parser: stateDiagram_default,
  get db() {
    return new StateDB(2);
  },
  renderer: stateRenderer_v3_unified_default,
  styles: styles_default,
  init: __name((cnf) => {
    if (!cnf.state) {
      cnf.state = {};
    }
    cnf.state.arrowMarkerAbsolute = cnf.arrowMarkerAbsolute;
  }, "init")
};
export {
  diagram
};
//# sourceMappingURL=stateDiagram-v2-MP3YSRHH-MDGBMXA7.js.map
