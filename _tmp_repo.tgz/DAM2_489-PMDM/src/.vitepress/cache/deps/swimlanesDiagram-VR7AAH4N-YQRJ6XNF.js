import {
  createFlowDiagram,
  styles_default
} from "./chunk-OT5JBOZV.js";
import "./chunk-4TNKLG3H.js";
import "./chunk-IFOGPCJD.js";
import "./chunk-QKWZG724.js";
import "./chunk-7GUCAR25.js";
import "./chunk-6WH7T6QG.js";
import "./chunk-LY6QTNXD.js";
import "./chunk-OLUBLFQS.js";
import "./chunk-S6W54RO2.js";
import "./chunk-LTYJNPJH.js";
import "./chunk-OAH2Y6RN.js";
import "./chunk-IBGCH5PM.js";
import "./chunk-WGPVAJBU.js";
import "./chunk-BDNRUUWP.js";
import "./chunk-66LTHK5N.js";
import "./chunk-BFAIJW6T.js";
import "./chunk-KEATWLHG.js";
import "./chunk-4ZOZIYPD.js";
import "./chunk-A5434355.js";
import {
  __name
} from "./chunk-DTCXZATX.js";
import "./chunk-X5QR3KD3.js";
import "./chunk-EQCVQC35.js";

// node_modules/mermaid/dist/chunks/mermaid.core/swimlanesDiagram-VR7AAH4N.mjs
var getStyles = __name((options) => `${styles_default(options)}
  .swimlane.cluster rect {
    stroke: ${options.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`, "getStyles");
var styles_default2 = getStyles;
var diagram = createFlowDiagram({ defaultLayout: "swimlane", styles: styles_default2 });
export {
  diagram
};
//# sourceMappingURL=swimlanesDiagram-VR7AAH4N-YQRJ6XNF.js.map
