// ============================================================================
// CONFIGURACIÓN DE UNIDADES — Navegación y Contenidos
// ============================================================================
//
// 👤 EDITA ESTE ARCHIVO para definir los módulos/unidades del curso
//    y su navegación (navbar y sidebar).
//
// CONCEPTOS CLAVE:
//   Unidad (unit) — Un bloque de contenido con su propia navegación.
//                   Puede ser una sesión, un tema, un capítulo, etc.
//   Navbar        — Menú horizontal en la barra superior.
//   Sidebar       — Panel de navegación lateral izquierdo.
//   code          — Prefijo de URL de los archivos de esta unidad.
//                   Ejemplo: code = 'general' → los links apuntan a /general/...
//
// FLUJO RÁPIDO:
//   1. Crea los archivos .md en src/<code>/contenidos/ y src/<code>/ejercicios/
//   2. Añade los links aquí (en navbar y sidebar)
//   3. El sistema detecta todas las unidades automáticamente:
//        /<code>/ → carga el sidebar de esa unidad
//        /        → raíz sin sidebar (página de inicio)
//
// ============================================================================

import { DefaultTheme } from 'vitepress'
import type { NavGroup } from '../shared/navigation'

// ============================================================================
// 1. NAVBARS Y SIDEBARS
// ============================================================================

// --- UP01 - Introducción a la programación móvil ---
const up01Items: DefaultTheme.SidebarItem[] = [
  { text: '🏠 Inicio', link: '/up01/' },
  // { text: '📚 Unidades',link: '/contenidos/01-UP01' },
]

const up01Sidebar: DefaultTheme.SidebarItem[] = [
  {
    text: '📚 Introducción a la programación móvil',
    collapsed: false,
    items: up01Items,
  },
 ]
  /* {
    text: '🛠️ Configura tu curso',
    collapsed: false,
    items: [
      { text: 'Curso único', link: '/contenidos/4-curso-unico' },
      { text: 'Curso modular', link: '/contenidos/5-curso-modular' },
      { text: 'Configuración e Identidad', link: '/contenidos/6-configuracion' },
    ]
  },
  {
    text: '✍️ Crea contenidos',
    collapsed: false,
    items: [
      { text: 'Crear Contenidos', link: '/contenidos/7-crear-contenidos' },
      { text: 'Catálogo de Componentes', link: '/contenidos/8-componentes' },
    ]
  },
  {
    text: '🎞️ Diapositivas e Imágenes',
    collapsed: true,
    items: [
      { text: 'Crear Diapositivas', link: '/contenidos/9-diapositivas' },
      { text: 'Catálogo de Patrones', link: '/contenidos/10-diapositivas-demo' },
      { text: 'Imágenes para Contenido', link: '/contenidos/11-imagenes' },
    ]
  },
  {
    text: '🌐 Publicación',
    collapsed: true,
    items: [
      { text: 'Despliegue', link: '/contenidos/12-despliegue' },
      { text: 'Privacidad y Acceso', link: '/contenidos/14-privacidad-acceso' },
    ]
  },
  {
    text: '📖Ejemplos',
    collapsed: true,
    items: [
      { text: 'Guia del curso', link: '/contenidos/13-ejemplo-guia' },
    ]
  },
  {
    text: '🗂️ Ejercicios',
    collapsed: true,
    items: [
      { text: 'Primera App Android', link: '/ejercicios/CodelabPrimeraAppAndroid' }
    ]
  }
] */

// ============================================================================
// 2. REGISTRO DE UNIDADES
// ============================================================================
// Añade, elimina o modifica entradas para gestionar los módulos del curso.
//
// Propiedades de cada unidad:
//   id        — Identificador único (debe coincidir con la clave del objeto)
//   code      — Prefijo de URL. Los links del navbar/sidebar se prefijarán
//               automáticamente con /<code>/
//               Ejemplo: code='s1' → '/contenidos/intro' → '/s1/contenidos/intro'
//   title     — Nombre corto (usado en migas de pan y referencias internas)
//   fullTitle — Nombre completo (aparece en la pestaña del navegador)
//   siteTitle — Nombre en el sidebar (puede usar </br> para saltos de línea)
//   icon      — Emoji decorativo del módulo
//   navbar    — Ítems del menú superior de esta unidad
//   sidebar   — Ítems del panel lateral de esta unidad

export interface UnitConfig {
  id: string
  code: string
  title: string
  fullTitle: string
  siteTitle: string
  icon: string
  navbar: DefaultTheme.NavItem[]
  sidebar: DefaultTheme.SidebarItem[]
}

export const UNITS: Record<string, UnitConfig> = {

  // Guía didáctica (src/index.md) — sin sidebar de curso.
  // Con varias unidades registradas, sus títulos son los del sitio completo.
  root: {
    id: 'root',
    code: 'root',
    title: 'PMDM',
    fullTitle: 'Modulo Profesional - Programación Multimedia y Dispositivos Móviles',
    siteTitle: 'Programación Multimedia</br>Dispositivos Móviles',
    icon: '📐',
    navbar: [{ text: '🏠 Guía Didáctica', link: '/' }],
    sidebar: []
  },

  UP01: {
    id: 'up01',
    code: 'up01',           // → archivos en src/up01/
    title: 'up01',
    fullTitle: 'UP01 — Introducción a la programación móvil',
    siteTitle: 'Programación Multimedia</br>y Dispositivos Móviles',
    icon: '📘',
    navbar: [{text: 'Guía Didáctica', link: '/' }],
    sidebar: up01Sidebar
  },

}

// ============================================================================
// FUNCIONES DE ACCESO — No modificar
// ============================================================================

export function getAllUnitsArray(): UnitConfig[] {
  return Object.values(UNITS)
}

export function getUnitByCode(code: string): UnitConfig | undefined {
  return UNITS[code]
}

// ── Navbar dinámico por unidad ───────────────────────────────────────────
// Desplegable «📚 Sesiones» que aparece en la barra superior solo cuando
// estás dentro de una sesión. Es acumulativo: dentro de la sesión N se
// listan la N y todas las anteriores, nunca las futuras.
//
// Al añadir la sesión 3: crear su entrada aquí copiando la lista de s2 y
// añadiendo la nueva línea al final.
const up01 = { text: 'UP01 — Introducción a la programación móvil', link: '/up01/contenidos/' }
// const S2 = { text: 'S2 — Metodologías Ágiles. Scrum',         link: '/s2/contenidos/' }

export const unitNavbars: Record<string, NavGroup[]> = {
	up01:[{ text: "Saberes", items: [up01] }],
}
